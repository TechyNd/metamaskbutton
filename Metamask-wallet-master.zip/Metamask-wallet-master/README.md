## Metamask Wallet

This Project helps to access Metamask wallet address and wallet balance when connected to it.

## Screenshot

![Screenshot](./src/assets/Screenshot.png)

## Built with:

- React
- Ethers.js
- CSS

## Links

[Livesite](https://mellow-valkyrie-9d3599.netlify.app/)